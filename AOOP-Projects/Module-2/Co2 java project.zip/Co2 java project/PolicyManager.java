import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class PolicyManager implements Iterable<InsurancePolicy> {
    private List<InsurancePolicy> policies;

    public PolicyManager() {
        policies = new ArrayList<>();
    }

    public void addPolicy(InsurancePolicy policy) {
        policies.add(policy);
    }

    public void removePolicy(InsurancePolicy policy) {
        policies.remove(policy);
    }

    public void sortPolicies() {
        Collections.sort(policies);
    }

    @Override
    public Iterator<InsurancePolicy> iterator() {
        return policies.iterator();
    }
}
