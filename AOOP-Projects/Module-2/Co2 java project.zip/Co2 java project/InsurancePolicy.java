import java.util.Objects;

public class InsurancePolicy implements Comparable<InsurancePolicy>, Cloneable {
    private String policyNumber;
    private String policyHolderName;
    private double premiumAmount;

    public InsurancePolicy(String policyNumber, String policyHolderName, double premiumAmount) {
        this.policyNumber = policyNumber;
        this.policyHolderName = policyHolderName;
        this.premiumAmount = premiumAmount;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getPolicyHolderName() {
        return policyHolderName;
    }

    public double getPremiumAmount() {
        return premiumAmount;
    }

    @Override
    public int compareTo(InsurancePolicy other) {
        return this.policyNumber.compareTo(other.policyNumber);
    }

    @Override
    protected InsurancePolicy clone() throws CloneNotSupportedException {
        return (InsurancePolicy) super.clone();
    }

    @Override
    public String toString() {
        return "InsurancePolicy{" +
                "policyNumber='" + policyNumber + '\'' +
                ", policyHolderName='" + policyHolderName + '\'' +
                ", premiumAmount=" + premiumAmount +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InsurancePolicy)) return false;
        InsurancePolicy that = (InsurancePolicy) o;
        return Double.compare(that.premiumAmount, premiumAmount) == 0 &&
                Objects.equals(policyNumber, that.policyNumber) &&
                Objects.equals(policyHolderName, that.policyHolderName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(policyNumber, policyHolderName, premiumAmount);
    }
}
