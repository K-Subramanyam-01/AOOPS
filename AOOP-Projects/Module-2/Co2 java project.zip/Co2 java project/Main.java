public class Main {
    public static void main(String[] args) {
        PolicyManager policyManager = new PolicyManager();

        // Adding policies
        policyManager.addPolicy(new InsurancePolicy("P001", "Alice", 1200.50));
        policyManager.addPolicy(new InsurancePolicy("P002", "Bob", 1500.75));
        policyManager.addPolicy(new InsurancePolicy("P003", "Charlie", 900.00));

        // Sorting policies
        policyManager.sortPolicies();

        // Displaying policies
        for (InsurancePolicy policy : policyManager) {
            System.out.println(policy);
        }

        // Cloning a policy
        try {
            InsurancePolicy clonedPolicy = policyManager.iterator().next().clone();
            System.out.println("Cloned Policy: " + clonedPolicy);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
